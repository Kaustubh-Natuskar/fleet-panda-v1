-- Grant privileges needed for Prisma migrations
-- This includes CREATE, ALTER, DROP for schema changes
-- and REFERENCES for foreign key constraints

GRANT CREATE, ALTER, DROP, REFERENCES ON *.* TO 'fleetuser'@'%';
FLUSH PRIVILEGES;
